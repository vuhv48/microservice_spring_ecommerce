package com.e_commerce.naming_eureka_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamingEurekaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
