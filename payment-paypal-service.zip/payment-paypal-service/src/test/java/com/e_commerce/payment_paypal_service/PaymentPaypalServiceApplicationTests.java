package com.e_commerce.payment_paypal_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentPaypalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
